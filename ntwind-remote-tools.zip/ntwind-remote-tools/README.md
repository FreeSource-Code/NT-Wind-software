
# NTWind Utilities: Screenshot Remote & Clipboard Remote

> Cross-platform productivity tools to boost your workflow.

## 📸 Screenshot Remote

[![Download ScreenshotRemote](https://img.shields.io/badge/Download-ScreenshotRemote-blue?style=for-the-badge&logo=windows)](ScreenshotRemote_1.0.9-win-x64.exe)

## 📋 Clipboard Remote

[![Download ClipboardRemote](https://img.shields.io/badge/Download-ClipboardRemote-blueviolet?style=for-the-badge&logo=windows)](ClipboardRemote_1.0.3-win-x64.exe)

## 📜 License

This software is free for personal use. All rights reserved by NTWind Software.
